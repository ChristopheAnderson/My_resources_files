Add the command \minitoclt where you want to print the minitoc,
minilof and minilot

If you want to know what I add to the template, search (CTRL+R)
"added", indeed without ("), in thé main.tex file and in the
MastersDoctoralThesis.cls